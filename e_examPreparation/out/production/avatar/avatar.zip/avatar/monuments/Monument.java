package avatar.monuments;

import avatar.core.Factory;

public class Monument implements Factory{
    private String name;
    private double affinity;

    public Monument(String name) {
        this.name = name;
    }


    public String getName() {
        return this.name;
    }

    public double getAffinity() {
        return this.affinity;
    }

    @Override
    public void setSecondElement(double secondElement) {

    }
}
