package avatar.core;

public interface Factory {
    public void setSecondElement(double secondElement);
    public double getTotal();
}

