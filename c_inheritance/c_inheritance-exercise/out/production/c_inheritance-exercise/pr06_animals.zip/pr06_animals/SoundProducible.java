package pr06_animals;


public interface SoundProducible {
    public String produceSound();
}
